public class parameters {

	public static void main (String[]args) {
		
		
		System.out.println (Addition(10,2));
		
		System.out.println (Addition(15,3));
	
	}

	private static int Addition (int a, int b) {
		
		
		return a+b;
		
		
		
		
		
	}
	
	 



	

}