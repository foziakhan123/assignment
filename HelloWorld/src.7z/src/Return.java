
public class Return {
	
	public static void main (String [] args)
	{
		System.out.println (HelloWorld("Hello World!"));
	
		
	}
	
	private static String HelloWorld(String HelloWorld) {
		return HelloWorld;
	}
	
	
	

}
