public class Hello {
	
	public static void main (String [] args)
	{
		
		Method ("Hello");
	}
	
	private static void Method (String Hello) {
		System.out.println (Hello);
		
		
	} 
}
