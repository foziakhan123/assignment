public class arrays2 {
	
	public static void main (String[]args) {

		int[] arrayofInts = new int[10];
		
		for(int i =0; i <10; i++) {
			
			System.out.println(arrayofInts [i] = i);
			
		
		}
		
		for (int i=0; i<10; i++) {
		System.out.println(arrayofInts [i]* 10 );
	
		
	}

}
	
}
