public class iterations {

	public static void main (String[]args) {
		
		for(int i =0; i <10; i++) {
			
			System.out.println(condition2.Addition(0,i,false));
			}
		
		
		
	}
		
		
		

}
