public class condition1 {
	
	

	public static void main (String[]args) {
		
		
		System.out.println (Addition (5,6, true));
		
		
	}
	 
	private static int Addition(int a, int b, boolean c ) {
	
	
	if (c) {
		return a+b; 
	}
	
	else {
		return a*b;
	}

}
	
	
}
