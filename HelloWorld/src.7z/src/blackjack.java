public class blackjack {
	
	public static void main (String[]args) {
		
		blackjack.black(2, 10); 
}
	
	public static int black (int a, int b) {
		
		if int a 
		
	}

}
