public class array {
	
	
	public static void main (String[]args) {

		int[] arrayofInts = {1,2,3,4,5,6,7,8,9,10};
		
		for(int i =0; i <10; i++) {
			System.out.println(condition2.Addition(0,arrayofInts[i],false));
		
		}
		
	
		
		
		
		
		
	}

}
